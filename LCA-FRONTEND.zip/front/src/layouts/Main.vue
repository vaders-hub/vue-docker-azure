<script lang="ts">
import { defineComponent, onMounted, reactive, watch } from "vue";

export default defineComponent({
  name: "Main",
  components: {},
  setup(context) {},
});
</script>

<template>
  <RouterView />
</template>
