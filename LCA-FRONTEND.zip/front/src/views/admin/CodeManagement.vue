<script lang="ts">
import { defineComponent, onMounted, ref } from "vue";
export default defineComponent({
  name: "CodeManagement",

  setup() {
    return {};
  },
});
</script>

<template>
  <div>CodeManagement</div>
</template>
