<script lang="ts">
import { defineComponent, onMounted, ref } from "vue";
export default defineComponent({
  name: "UserManagement",

  setup() {
    return {};
  },
});
</script>

<template>
  <div>UserManagement</div>
</template>
