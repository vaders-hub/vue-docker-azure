<script lang="ts">
import { defineComponent, onMounted, reactive, watch } from 'vue'

export default defineComponent({
  name: 'Net-Zero',
  components: {},
  setup(context) {
    return {}
  },
})
</script>

<template>
  <h2>Net-Zero</h2>
</template>
