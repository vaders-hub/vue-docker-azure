<script lang="ts">
import { defineComponent, onMounted, ref } from "vue";
export default defineComponent({
  name: "NotFound",

  setup() {
    return {};
  },
});
</script>

<template>
  <h1>Not Found</h1>
  <div></div>
</template>
