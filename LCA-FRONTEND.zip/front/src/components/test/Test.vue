<script>
$(function () {
  $('#target').click(function () {
    alert('clicked')
  })
})

export default {}
</script>
<template>
  <button id="target">jquery click test</button>
  <div>Test</div>
</template>
